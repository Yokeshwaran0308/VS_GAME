# /// script
# dependencies = [
#     "pygame-ce",
# ]
# ///

import asyncio
import random
import pygame


# =========================
# SETTINGS
# =========================

WIDTH = 800
HEIGHT = 600

SNAKE_BLOCK = 20
FPS = 10


# =========================
# COLORS
# =========================

BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
DARK_GREEN = (0, 150, 0)
RED = (255, 60, 60)
WHITE = (255, 255, 255)
GRAY = (150, 150, 150)


# =========================
# DRAW SNAKE
# =========================

def draw_snake(screen, snake_list):

    for i, block in enumerate(snake_list):

        if i == len(snake_list) - 1:
            color = GREEN
        else:
            color = DARK_GREEN

        pygame.draw.rect(
            screen,
            color,
            (
                block[0],
                block[1],
                SNAKE_BLOCK,
                SNAKE_BLOCK
            )
        )


# =========================
# SCORE
# =========================

def show_score(screen, font, score):

    text = font.render(
        f"Score: {score}",
        True,
        WHITE
    )

    screen.blit(text, (10, 10))


# =========================
# CENTER TEXT
# =========================

def center_text(screen, font, text, color, y):

    message = font.render(
        text,
        True,
        color
    )

    rect = message.get_rect(
        center=(WIDTH // 2, y)
    )

    screen.blit(message, rect)


# =========================
# WAIT FOR START
# =========================

async def start_screen(screen, font):

    waiting = True

    while waiting:

        screen.fill(BLACK)

        center_text(
            screen,
            font,
            "SNAKE GAME",
            GREEN,
            200
        )

        center_text(
            screen,
            font,
            "CLICK / TOUCH TO START",
            WHITE,
            280
        )

        center_text(
            screen,
            font,
            "Use Arrow Keys to Move",
            GRAY,
            330
        )

        pygame.display.flip()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                return False

            if event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

            if event.type == pygame.KEYDOWN:

                if event.key in (
                    pygame.K_SPACE,
                    pygame.K_RETURN
                ):
                    waiting = False

        await asyncio.sleep(0)

    return True


# =========================
# GAME OVER SCREEN
# =========================

async def game_over_screen(screen, font, score):

    waiting = True

    while waiting:

        screen.fill(BLACK)

        center_text(
            screen,
            font,
            "GAME OVER",
            RED,
            190
        )

        center_text(
            screen,
            font,
            f"Score: {score}",
            WHITE,
            250
        )

        center_text(
            screen,
            font,
            "Press R or Click to Restart",
            WHITE,
            310
        )

        center_text(
            screen,
            font,
            "Press Q to Quit",
            GRAY,
            360
        )

        pygame.display.flip()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                return "quit"

            if event.type == pygame.MOUSEBUTTONDOWN:
                return "restart"

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_r:
                    return "restart"

                if event.key == pygame.K_q:
                    return "quit"

        await asyncio.sleep(0)

    return "restart"


# =========================
# SNAKE GAME
# =========================

async def play_game(screen, font, clock):

    # Starting position
    x = WIDTH // 2
    y = HEIGHT // 2

    x_change = 0
    y_change = 0

    snake_list = []
    snake_length = 1

    # Food position
    food_x = random.randrange(
        0,
        WIDTH - SNAKE_BLOCK,
        SNAKE_BLOCK
    )

    food_y = random.randrange(
        0,
        HEIGHT - SNAKE_BLOCK,
        SNAKE_BLOCK
    )

    game_over = False

    while not game_over:

        # =========================
        # EVENTS
        # =========================

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                return "quit"

            if event.type == pygame.KEYDOWN:

                # LEFT
                if (
                    event.key == pygame.K_LEFT
                    and x_change == 0
                ):
                    x_change = -SNAKE_BLOCK
                    y_change = 0

                # RIGHT
                elif (
                    event.key == pygame.K_RIGHT
                    and x_change == 0
                ):
                    x_change = SNAKE_BLOCK
                    y_change = 0

                # UP
                elif (
                    event.key == pygame.K_UP
                    and y_change == 0
                ):
                    y_change = -SNAKE_BLOCK
                    x_change = 0

                # DOWN
                elif (
                    event.key == pygame.K_DOWN
                    and y_change == 0
                ):
                    y_change = SNAKE_BLOCK
                    x_change = 0

        # =========================
        # MOVE
        # =========================

        x += x_change
        y += y_change

        # =========================
        # WALL COLLISION
        # =========================

        if (
            x < 0
            or x >= WIDTH
            or y < 0
            or y >= HEIGHT
        ):
            game_over = True

        # =========================
        # SNAKE HEAD
        # =========================

        snake_head = [x, y]

        snake_list.append(snake_head)

        if len(snake_list) > snake_length:
            del snake_list[0]

        # =========================
        # SELF COLLISION
        # =========================

        for block in snake_list[:-1]:

            if block == snake_head:
                game_over = True

        # =========================
        # DRAW
        # =========================

        screen.fill(BLACK)

        # Food
        pygame.draw.rect(
            screen,
            RED,
            (
                food_x,
                food_y,
                SNAKE_BLOCK,
                SNAKE_BLOCK
            )
        )

        # Snake
        draw_snake(
            screen,
            snake_list
        )

        # Score
        show_score(
            screen,
            font,
            snake_length - 1
        )

        pygame.display.flip()

        # =========================
        # FOOD COLLISION
        # =========================

        if x == food_x and y == food_y:

            snake_length += 1

            food_x = random.randrange(
                0,
                WIDTH - SNAKE_BLOCK,
                SNAKE_BLOCK
            )

            food_y = random.randrange(
                0,
                HEIGHT - SNAKE_BLOCK,
                SNAKE_BLOCK
            )

        # =========================
        # FPS
        # =========================

        clock.tick(FPS)

        # Give control back to browser
        await asyncio.sleep(0)

    return "game_over"


# =========================
# MAIN
# =========================

async def main():

    pygame.init()

    screen = pygame.display.set_mode(
        (WIDTH, HEIGHT)
    )

    pygame.display.set_caption(
        "Snake Game"
    )

    clock = pygame.time.Clock()

    font = pygame.font.Font(
        None,
        35
    )

    # =========================
    # START SCREEN
    # =========================

    started = await start_screen(
        screen,
        font
    )

    if not started:
        pygame.quit()
        return

    # =========================
    # MAIN GAME LOOP
    # =========================

    while True:

        result = await play_game(
            screen,
            font,
            clock
        )

        if result == "quit":
            break

        if result == "game_over":

            result = await game_over_screen(
                screen,
                font,
                0
            )

            if result == "quit":
                break

    pygame.quit()


# =========================
# START PROGRAM
# =========================

if __name__ == "__main__":
    asyncio.run(main())
